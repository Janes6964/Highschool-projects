package ia1;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.util.concurrent.TimeUnit;
import java.awt.event.KeyEvent;

public class InitializeP extends JFrame {
	/**
	 * this class initiates a person in the database file
	 * 
	 * @author Janes99
	 */
	private String fnameEnter, lnameEnter, subjectEnter, languageEnter;
	private int gradeEnter, markEnter;
	private JTextField lname, fname, gradelvl, subject, mark, langlvl;

	public InitializeP() {
		super("Initialize Student");

		// splits the screen panel into halves
		// the top is used for the display and instructions
		// the bottom is used for the function
		GridLayout myLayout = new GridLayout(2, 1);
		setLayout(myLayout);

		// setting the panel above the mid-line
		JPanel instructions = new JPanel();
		String path = "/Users/Janes99/Desktop/CS_Materials/Initialize.png";
		ImageIcon picture = new ImageIcon(path);

		JLabel picLabel = new JLabel("", picture, JLabel.CENTER);
		instructions.add(picLabel, BorderLayout.CENTER);
		add(instructions, BorderLayout.CENTER);
		
		
		// this sets initial graph panel

		JPanel input = new JPanel();
		input.setBounds(450, 25, 200, 400);
		add(input);
		input.setLayout(new GridLayout(7, 2));

		// first name label
		JLabel fnameLabel = new JLabel("First Name:", JLabel.CENTER);
		input.add(fnameLabel);

		// first name text field
		fname = new JTextField("Enter First Name");
		fname.setLayout(null);
		input.add(fname);

		// last name label
		JLabel lnameLabel = new JLabel("Last Name:", JLabel.CENTER);
		input.add(lnameLabel);

		// last name text field
		lname = new JTextField("Enter Last Name");
		lname.setLayout(null);
		input.add(lname);

		// grade level label
		JLabel gradeLabel = new JLabel("Grade Level:", JLabel.CENTER);
		input.add(gradeLabel);

		// grade label text field
		gradelvl = new JTextField("Enter Grade Level");
		gradelvl.setLayout(null);
		input.add(gradelvl);

		// subject area label
		JLabel subjectLabel = new JLabel("Subject Area:", JLabel.CENTER);
		input.add(subjectLabel);

		// subject area text field
		subject = new JTextField("Enter subject");
		subject.setLayout(null);
		input.add(subject);

		// total marks label
		JLabel markLabel = new JLabel("Total Marks", JLabel.CENTER);
		input.add(markLabel);

		// total marks text field
		mark = new JTextField("Enter Marks");
		mark.setLayout(null);
		input.add(mark);

		// language level label
		JLabel langlabel = new JLabel("Language Level", JLabel.CENTER);
		input.add(langlabel);

		// language level text field
		langlvl = new JTextField("Enter Language Level");
		langlvl.setLayout(null);
		input.add(langlvl);

		JButton initializeconfirm = new JButton("Confirm");
		input.add(initializeconfirm);

		initializeconfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonpressed();
				// showing success cna be done through the top half of
				// the panel showing the success message
				// these are whatever
				// confirmMSG.setText("Confirmed.");
				/*
				 * try { Thread.sleep(10000); } catch(InterruptedException ex) {
				 * Thread.currentThread().interrupt(); } try {
				 * Thread.sleep(10000); } catch(InterruptedException ex) {
				 * Thread.currentThread().interrupt(); }
				 * 
				 * confirmMSG.setText("after");
				 * 
				 */
			}
		});

		// plot poly or to display a message saying that it's confirmed
		// for the codes
		// add a new button for renew every textfield

		// close current window maybee?

		// endings
		setSize(450, 850);

		setVisible(true);
	}

	public void buttonpressed() {
		// this stores what the user enters

		fnameEnter = fname.getText();
		lnameEnter = lname.getText();
		subjectEnter = subject.getText();
		languageEnter = langlvl.getText();

		gradeEnter = Integer.parseInt(gradelvl.getText());
		markEnter = Integer.parseInt(mark.getText());

		DBCommunicator initializeComm = null;
		try {
			initializeComm = new DBCommunicator("jdbc:sqlite://Users//Janes99//sqlite//students.db");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			return;
		}
		// this connects the newly entered information to the database
		initializeComm.addStudent(fnameEnter, lnameEnter, gradeEnter, subjectEnter, markEnter, languageEnter);
		// add success message here?
	}

	class Instructions extends JPanel {
		// this is where you put the picture in
	}
}
