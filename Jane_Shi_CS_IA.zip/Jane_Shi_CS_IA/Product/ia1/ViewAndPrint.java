package ia1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.*;

public class ViewAndPrint extends JFrame {
	public String fname, outcomeAcademics, outcomeSchedule;
	public JTextArea profile;
	public JTextField fnameEnter;
	public JButton confirm, print;
	private Graphics2D images;

	public ViewAndPrint() {
		/**
		 * This allows the users to view the students' full progile and to view
		 * their report card
		 * 
		 * @author Janes99
		 */

		super("View and Print Student Profile");

		// this sets up this java frame
		GridLayout myLayout = new GridLayout(2, 1);
		setLayout(myLayout);

		JPanel results = new JPanel();

		add(results);

		// this is where the profile information will be
		profile = new JTextArea(20, 30);
		profile.setEditable(false);
		results.add(profile);

		// this panel will allow the students to enter information
		JPanel options = new JPanel();

		GridLayout gridchoices = new GridLayout(3, 1);
		options.setLayout(gridchoices);

		fnameEnter = new JTextField("Enter First Name", JLabel.CENTER);
		JButton confirm = new JButton("Confirm");
		JButton print = new JButton("Print Report");

		// these initialize the buttons
		options.add(fnameEnter);
		options.add(confirm);
		options.add(print);
		add(options);

		// this sets up the java frame
		setSize(450, 850);
		setVisible(true);

		// this associates the buttons with the actionlisteners
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				viewbuttonpressed();
			}
		});

		print.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent m) {
				printbuttonpressed();
			}
		});

	}

	public void printbuttonpressed() {
		
		fname = fnameEnter.getText();
		
		UIManager.put("swing.boldMetal", Boolean.FALSE);
		JFrame printPrompt = new JFrame("Printing confirm");
	
		JButton printButton = new JButton("Confirm printing");
		printButton.addActionListener(new ReportPrinter(fname));
		printPrompt.add("Center", printButton);
		printPrompt.pack();
		printPrompt.setVisible(true);
		
	}

	// this method will allow the user to view students' entered information
	public void viewbuttonpressed() {
		profile.setText(null);
		fname = fnameEnter.getText();
		DBCommunicator viewComm = null;
		try {
			viewComm = new DBCommunicator("jdbc:sqlite://Users//Janes99//sqlite//students.db");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			return;
		}
		outcomeAcademics = viewComm.getReport(fname);
		outcomeSchedule = viewComm.getScheduleReport(fname);
		profile.append(outcomeAcademics + outcomeSchedule);
		// this will append both of the academic reports and the schedule
		// reports on the text area above
	}

}
