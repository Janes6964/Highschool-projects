package ia1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;

public class IA extends JFrame {
/**
 * This is the main class, which will open up a frame with several options that the user can choose,
 * in order to update with databse
 * @author Janes99
 */

	public IA() throws IOException, SQLException {
		//making the main panel
		super("Bookkeeping System");
		JPanel major = new JPanel();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());

		major.setBounds(25, 25, 400, 400);
		major.setBorder(BorderFactory.createLineBorder(Color.blue));
		major.setBackground(Color.white);
		major.setVisible(true);

		//making buttons and add buttons
		JButton initialize = new JButton("Initialize Profile");
		JButton paydates = new JButton("Change Schedule information");
		JButton gradeslevel = new JButton("Change Academic information");
		JButton viewandprint = new JButton("View and print profile");

		major.add(initialize);
		major.add(paydates);
		major.add(gradeslevel);
		major.add(viewandprint);

		add(major);

		setSize(250, 200);

		setVisible(true);

		//this associates buttons to the new hava frames that they are connected to,
		//allowing the user to access the database
		
		initialize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InitializeP p = new InitializeP();
				//initializes a student's information
			}
		});

		paydates.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PayAndDate p = new PayAndDate();
				// Allows users to alter the schedule information and
				// to which day the pay is paid
			}
		});

		gradeslevel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EnterGrades p = new EnterGrades();
				// allows users to change total marks
				// subject, grade level and language level
			}
		});

		viewandprint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewAndPrint open = new ViewAndPrint();
				// this allows the teacher
				// to view the student's report
				// and to print the page
			}
		});

		// this initiates the database file as soon as the main class is compiled
		DBCommunicator comm = null;
		try {
			comm = new DBCommunicator("jdbc:sqlite://Users//Janes99//sqlite//students.db");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			return;
		}
	
		// create the gui class within here

		// UML diagram

	}

	public static void main(String[] args) throws IOException, SQLException {
		IA apenAssessment = new IA();
	}
}