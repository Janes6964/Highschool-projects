package ia1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

public class PayAndDate extends JFrame {
	private String fnameEnter, scheduleEnter, payDateEnter;
	private JTextField fname, schedule, payDate;
/**
 * this allows the user to update the schedule for classes, as well as
 * when the classes are paid until
 * @author Janes99
 */
	public PayAndDate() {
		super("Alter Student Payment and schedule");

		GridLayout myLayout = new GridLayout(2, 1);
		setLayout(myLayout);

		// setting the panel above the mid-line, which has instructions
		JPanel instructions = new JPanel();
		String path = "/Users/Janes99/Desktop/CS_Materials/EnterDate.png";
		ImageIcon picture = new ImageIcon(path);
			
		JLabel picLabel = new JLabel("", picture, JLabel.CENTER);
		instructions.add(picLabel, BorderLayout.CENTER);
		add(instructions, BorderLayout.CENTER);
			

		JPanel input = new JPanel();
		input.setBounds(450, 25, 200, 400);
		add(input);
		input.setLayout(new GridLayout(4, 2));

		// first name label
		JLabel fnameLabel = new JLabel("First Name:", JLabel.CENTER);
		input.add(fnameLabel);

		// first name text field
		fname = new JTextField("Enter First Name");
		fname.setLayout(null);
		input.add(fname);

		// schedule date label
		JLabel scheduleLabel = new JLabel("Course Schedule:", JLabel.CENTER);
		input.add(scheduleLabel);

		// schedule date text field
		schedule = new JTextField("Set Schedule");
		schedule.setLayout(null);
		input.add(schedule);

		// Payment label
		JLabel payDateLabel = new JLabel("Classes paid until", JLabel.CENTER);
		input.add(payDateLabel);

		// Payment text field
		payDate = new JTextField("Update paid date");
		payDate.setLayout(null);
		input.add(payDate);

		JButton confirm = new JButton("Confirm updated information");
		input.add(confirm);

		setSize(450, 850);
		setVisible(true);

		//this adds an action listener to the button
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonpressed();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

	}

	//this stores information in the database whenever the button is pressed
	public void buttonpressed() throws IOException, SQLException {
		
		//establish the connection with database
		DBCommunicator payAndDate = null;

		try {
			payAndDate = new DBCommunicator("jdbc:sqlite://Users//Janes99//sqlite//students.db");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			return;
		}

		fnameEnter = fname.getText();
		scheduleEnter = schedule.getText();
		payDateEnter = payDate.getText();

		// this stores what the user entered in the text field into the database
		//note that if the entered information is completely empty or it is unaltered,
		//the data will not be changed. 
		
		if (scheduleEnter.trim().length() > 0 && (scheduleEnter.equals("Set Schedule")) == false) {
			payAndDate.updateSchedule(fnameEnter, scheduleEnter);
		}

		if (payDateEnter.trim().length() > 0 && (payDateEnter.equals("Update paid date")) == false) {
			payAndDate.updatePaydate(fnameEnter, payDateEnter);
		}
	}
}
