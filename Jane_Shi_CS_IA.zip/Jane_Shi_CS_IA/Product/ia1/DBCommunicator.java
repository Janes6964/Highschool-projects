package ia1;

import java.util.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This class provides methods for communicating with a SQLite database that
 * contains student information.
 * 
 * @author Janes99
 *
 */

public class DBCommunicator {
	private Connection connection;

	public DBCommunicator(String path) throws ClassNotFoundException {
		// import SQLite driver
		Class.forName("org.sqlite.JDBC");

		try {
			// create a database connection
			connection = DriverManager.getConnection(path);
			Statement s = connection.createStatement();
			s.setQueryTimeout(30); // set timeout to 30 seconds
			// create Students table
			s.executeUpdate("CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY, fname TEXT, "
					+ "lname TEXT, gradelvl INTEGER, " + "subject TEXT, totalmark INTEGER, "
					+ "langlevel TEXT, comment TEXT, schedule TEXT," + "payment TEXT, paydate DATE)");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			// an error message will show, if no database file is there
		}
	}

	public void close() {
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			System.err.println(e);
			// this wraps the communication in a try catch error block
			// and this close the connection between java class and the database
			// file
		}
	}

	public void addStudent(String fname, String lname, int gradelvl, String subject, int totalmark, String langlevel) {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30); // set timeout to 30 sec
			s.executeUpdate("INSERT INTO students(fname, lname, gradelvl, subject, totalmark, langlevel) VALUES ('"
					+ fname + "','" + lname + "','" + gradelvl + "','" + subject + "','" + totalmark + "','" + langlevel
					+ "')");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
	// this adds a student to the column, from the interface. When you add a
	// student those
	// information to be entered, are absolutely mandatory

	public String getScheduleReport(String fname) {
		String resultx = "";
		String resulty = "";
		try {
			Statement s = connection.createStatement();
			ResultSet r = s.executeQuery("SELECT schedule FROM students WHERE fname='" + fname + "'");
			while (r.next()) {
				resultx = r.getString("schedule");
			}

			r = s.executeQuery("SELECT payment FROM students WHERE fname='" + fname + "'");
			while (r.next()) {
				resulty = r.getString("payment");
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return "\n \n \n The Schedule is set for: " + resultx + "\n Classes are paid until: " + resulty + "";
	}
	// the getScheduleReport method returns the schedule and paid- class- date
	// information
	// from a certain row, defined by student's first name

	public String getReport(String fname) {

		// initialize strings / integers
		String lNameResult = "";
		int gradelvlResult = 0;
		String subjectResult = "";
		int totalmarkResult = 0;
		String langlvlResult = "";
		String comments = "";

		// access and store the information from database
		try {
			Statement s = connection.createStatement();
			ResultSet r = s.executeQuery("SELECT * FROM students WHERE fname='" + fname + "'");
			while (r.next()) {
				lNameResult = r.getString("lname");
				gradelvlResult = r.getInt("gradelvl");
				subjectResult = r.getString("subject");
				totalmarkResult = r.getInt("totalmark");
				langlvlResult = r.getString("langlevel");
				comments = r.getString("comment");

			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}

		// return a string containing the obtained information from the database
		String records = "\n \n \n First name: " + fname + "\n Last name: " + lNameResult + "\n Grade level:"
				+ Integer.toString(gradelvlResult) + "\n Subject Area:" + subjectResult + "\n Total mark: "
				+ Integer.toString(totalmarkResult) + "\n Language level: " + langlvlResult + "\n Comment: " + comments;
		return records;
	}
	// the getReport method returns lots of academic information about the
	// student
	// which is defined by the first name entered

	public void updateGradeLevel(String fname, int gradeLevel) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30); // set timeout to 30 sec
			String updateGradeSQL = "UPDATE students set gradelvl = " + gradeLevel + " WHERE fname = '" + fname + "';";
			s.executeUpdate(updateGradeSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	// updates a student's grade level, where the student is defined by the
	// first name

	public void updateMarks(String fname, int marks) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30); // set timeout to 30 sec
			String updateMarkSQL = "UPDATE students set totalmark = " + marks + " WHERE fname = '" + fname + "';";
			s.executeUpdate(updateMarkSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	// updates a student's marks, where the student is defined by the first name

	public void updateLanguageLevel(String fname, String langLevel) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30);
			String updateLanglvlSQL = "UPDATE students set langlevel = '" + langLevel + "' WHERE fname = '" + fname
					+ "';";
			s.executeUpdate(updateLanglvlSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	// updates a student's language level, where the student is defined by the
	// first name

	public void updateSubject(String fname, String subject) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30);
			String updateSubjectSQL = "UPDATE students set subject = '" + subject + "' WHERE fname = '" + fname + "';";
			s.executeUpdate(updateSubjectSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	// updates a student's subject area, where the student is defined by the
	// first name

	public void updateComment(String fname, String comments) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30);
			String updateCommentSQL = "UPDATE students set comment = '" + comments + "' WHERE fname = '" + fname + "';";
			s.executeUpdate(updateCommentSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	// updates a student's comments, where the student is defined by the first
	// name

	public void updateSchedule(String fname, String date) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30);
			String updateScheduleSQL = "UPDATE students set schedule = '" + date + " ' WHERE fname = '" + fname + "';";
			s.executeUpdate(updateScheduleSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	// updates a student's schedule, where the student is defined by the first
	// name

	public void updatePaydate(String fname, String paydate) throws IOException, SQLException {
		try {
			Statement s = connection.createStatement();
			s.setQueryTimeout(30);
			String updatePayDateSQL = "UPDATE students set payment = '" + paydate + " ' WHERE fname = '" + fname + "';";
			s.executeUpdate(updatePayDateSQL);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	
	// updates when the classes are paid until, for a student, where the student
	// is defined by the first name

	// the below method returns an arraylist that
	// stores the student's information as Strings,
	// which is used for the formatting for printing
	
	public ArrayList<String> EveryInformation(String fname) throws IOException, SQLException {
		ArrayList<String> information = new ArrayList<String>();

		// initialize strings / integers
		String lNameResult = "";
		int gradelvlResult = 0;
		String subjectResult = "";
		int totalmarkResult = 0;
		String langlvlResult = "";
		String comments = "";
		String resultSchedule = "";
		String resultDate = "";
		
		// access and store the information from database
		try {
			Statement s = connection.createStatement();
			ResultSet r = s.executeQuery("SELECT * FROM students WHERE fname='" + fname + "'");
			while (r.next()) {
				lNameResult = r.getString("lname");
				gradelvlResult = r.getInt("gradelvl");
				subjectResult = r.getString("subject");
				totalmarkResult = r.getInt("totalmark");
				langlvlResult = r.getString("langlevel");
				comments = r.getString("comment");
				resultSchedule = r.getString("schedule");
				resultDate = r.getString("payment");
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		
		information.add(lNameResult);
		information.add(Integer.toString(gradelvlResult));
		information.add(subjectResult);
		information.add(Integer.toString(totalmarkResult));
		information.add(langlvlResult);
		information.add(comments);
		information.add(resultSchedule);
		information.add(resultDate);
		
		return information;
	}
}
