package ia1;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JTextField;

public class ReportPrinter implements Printable, ActionListener {
	public String fnameDetector = null;

	public ReportPrinter(String STR) {
		fnameDetector = STR;
	}

	public int print(Graphics graph, PageFormat format, int pagenumber) throws PrinterException {
		if (pagenumber > 0) { 
			//this happens when only one page is printed
			return NO_SUCH_PAGE;
		}
		
		DBCommunicator viewComm = null;
		try {
			viewComm = new DBCommunicator("jdbc:sqlite://Users//Janes99//sqlite//students.db");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());

		}
		
		
		ArrayList<String> outcome = null;
		try {
			outcome = viewComm.EveryInformation(fnameDetector);
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Iterator<String> infoIter = outcome.iterator();
		
		//this stores the database information to local, for printing convenience
	
		String fnameResult = fnameDetector;
		String lNameResult = infoIter.next();
		String gradelvlResult = infoIter.next();
		String subjectResult = infoIter.next();
		String totalmarkResult = infoIter.next();
		String langlvlResult = infoIter.next();
		String comments = infoIter.next();
		String resultSchedule = infoIter.next();
		String resultDate = infoIter.next();
		
		// this will print our information in a desired area, so that 
		// the printer can print in the imageable area

		Graphics2D dimensions = (Graphics2D) graph;
		dimensions.translate(format.getImageableX(), format.getImageableY());

		//now this reads the information and prints our desired information
		
		graph.drawString(fnameDetector,100, 75);
		graph.drawString("This is the student report for: ", 100, 100);
		graph.drawString("Student: "+ fnameResult + "  "+lNameResult, 100, 150);
		graph.drawString("Grade Level: "+gradelvlResult, 100, 200);
		graph.drawString("Subject:  "+ subjectResult, 100, 250);
		graph.drawString("Total Mark is:  "+totalmarkResult, 100, 300);
		graph.drawString("Language level: "+langlvlResult, 100, 350);
		graph.drawString("Schedule information is shown below: ", 100, 450);
		graph.drawString("Classes scheduled for:  "+ resultSchedule, 100, 500);
		graph.drawString("Classes until this date are paid: " + resultDate, 100, 550);
		graph.drawString("Comments:", 100, 650);
		graph.drawString(comments, 100, 700);
		
		
		graph.drawString(outcome.get(2), 100, 770);
		return PAGE_EXISTS;
	}

	public void actionPerformed(ActionEvent e)
	{
		PrinterJob reportJob = PrinterJob.getPrinterJob();
		reportJob.setPrintable(this);
		boolean printable = reportJob.printDialog();
		if (printable) {
			try {
				reportJob.print();
			} catch (PrinterException ex) {
				//if the job isnt completed
			}
		}
	
	}}
