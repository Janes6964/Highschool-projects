package ia1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.lang.Object;

public class EnterGrades extends JFrame {

	/**
	 * This opens up a new frame (Window) with prompts to alter student's
	 * academic information such as grade level, language level, subjects, and
	 * marks. This is based on student's first name. This panel is designed so
	 * that the user can change anywhere from one entry to all entries in the
	 * database at once.
	 */
	private String fnameEnter, languageLvlEnter, commentsEnter, subjectEnter;
	private JTextField fname, gradelvl, languagelvl, subject, marks;
	private JTextArea comments;
	private int gradeEnter, marksEnter;

	// grades and comments
	public EnterGrades() {
		super("Alter Student Academic Information");

		// this is for changing grade level, marks, language level,
		// and comments in terms of the academics

		// setting the layout
		GridLayout myLayout = new GridLayout(3, 1);
		setLayout(myLayout);

		// setting the panel above the mid-line
		JPanel instructions = new JPanel();
		String path = "/Users/Janes99/Desktop/CS_Materials/EnterGradesInstructions.png";
		ImageIcon picture = new ImageIcon(path);
		
		JLabel picLabel = new JLabel("", picture, JLabel.CENTER);
		instructions.add(picLabel, BorderLayout.CENTER);
		add(instructions, BorderLayout.CENTER);
		
		// this sets the initial graph panel

		JPanel input = new JPanel();
		input.setBounds(450, 25, 200, 400);
		add(input);
		input.setLayout(new GridLayout(5, 2));

		// first name label
		JLabel fnameLabel = new JLabel("First Name:", JLabel.CENTER);
		input.add(fnameLabel);

		// first name text field
		fname = new JTextField("Enter First Name");
		fname.setLayout(null);
		input.add(fname);

		// Grade level label
		JLabel gradeLabel = new JLabel("Grade Level:", JLabel.CENTER);
		input.add(gradeLabel);

		// Grade Level text field
		gradelvl = new JTextField("NEW Grade Level");
		gradelvl.setLayout(null);
		input.add(gradelvl);

		// language level label
		JLabel languageLvlLabel = new JLabel("Language Level:", JLabel.CENTER);
		input.add(languageLvlLabel);

		// language level field
		languagelvl = new JTextField("NEW Language Level");
		languagelvl.setLayout(null);
		input.add(languagelvl);

		// subject label
		JLabel subjectLabel = new JLabel("Subject Area:", JLabel.CENTER);
		input.add(subjectLabel);

		// subject text field
		subject = new JTextField("NEW Subject Area");
		subject.setLayout(null);
		input.add(subject);

		// total marks field
		JLabel marksLabel = new JLabel("Marks:", JLabel.CENTER);
		input.add(marksLabel);

		// total marks text field
		marks = new JTextField("NEW Marks");
		marks.setLayout(null);
		input.add(marks);

		// comment label
		JPanel commentPanel = new JPanel();
		add(commentPanel);

		// set up the comment text field
		BorderLayout commentsLO = new BorderLayout();
		commentPanel.setLayout(commentsLO);

		comments = new JTextArea(3, 3);
		commentPanel.add(comments, BorderLayout.CENTER);
		comments.setText("Please type in new comments, otherwise leave it blank");

		comments.setEditable(true);

		// creating a button
		JButton confirm = new JButton("Confirm your change");
		commentPanel.add(confirm, BorderLayout.PAGE_START);

		// initializing the frame
		setSize(450, 850);
		setVisible(true);

		// add an action listener on that button to do the "button pressed"
		// method

		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buttonpressed();
				} catch (IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

	}

	// this is a method when a button is pressed
	public void buttonpressed() throws IOException, SQLException {

		// connect to the database
		DBCommunicator academics = null;

		try {
			academics = new DBCommunicator("jdbc:sqlite://Users//Janes99//sqlite//students.db");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			return;
		}

		// this stores what the user puts in each text field
		fnameEnter = fname.getText();
		languageLvlEnter = languagelvl.getText();
		commentsEnter = comments.getText();
		subjectEnter = subject.getText();

		String STRgradeEnter = gradelvl.getText();
		String STRmarksEnter = marks.getText();

		// The below codes update what the user enters to the database. If the
		// entered information is
		// all blank strings, or if it is unaltered, then the information will
		// not be stored.
		// this way, the user can update only one of the academic information
		// entries, without having to
		// change everything else

		if (STRgradeEnter.trim().length() > 0 && ((STRgradeEnter).equals("NEW Grade Level")) == false) {
			gradeEnter = Integer.parseInt(STRgradeEnter);
			academics.updateGradeLevel(fnameEnter, gradeEnter);
		}

		if (STRmarksEnter.trim().length() > 0 && ((STRmarksEnter).equals("NEW Marks")) == false) {
			marksEnter = Integer.parseInt(STRmarksEnter);
			academics.updateMarks(fnameEnter, marksEnter);
		}

		if (languageLvlEnter.trim().length() > 0 && ((languageLvlEnter).equals("NEW Language Level")) == false) {
			academics.updateLanguageLevel(fnameEnter, languageLvlEnter);
		}

		if (subjectEnter.trim().length() > 0 && ((subjectEnter).equals("NEW Subject Area")) == false) {
			academics.updateSubject(fnameEnter, subjectEnter);
		}

		if (commentsEnter.trim().length() > 0
				&& ((commentsEnter).equals("Please type in new comments, otherwise leave it blank")) == false) {
			academics.updateComment(fnameEnter, commentsEnter);
		}

	}

}
